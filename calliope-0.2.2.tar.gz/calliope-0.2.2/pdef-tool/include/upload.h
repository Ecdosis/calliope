/* 
 * File:   archive.h
 * Author: desmond
 *
 * Created on May 27, 2012, 10:09 AM
 */

#ifndef ARCHIVE_H
#define	ARCHIVE_H
#ifdef	__cplusplus
extern "C" {
#endif
int archive_scan();

#ifdef	__cplusplus
}
#endif

#endif	/* ARCHIVE_H */

