#!/bin/sh
curl -X GET http://localhost:8080/html/english/shakespeare/kinglear/act1/scene1/F1

