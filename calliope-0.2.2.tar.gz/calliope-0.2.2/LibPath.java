public class LibPath
{
    public static void main( String[] args )
    {
        System.out.print(System.getProperty("java.library.path"));
    }
}
