/* 
 * File:   AESE.h
 * Author: desmond
 *
 * Created on 18 April 2011, 8:08 AM
 */

#ifndef AESE_H
#define	AESE_H
#ifdef	__cplusplus
extern "C" {
#endif
int load_aese_markup( const char *data, int len, range_array *ranges, hashset *props );
#ifdef	__cplusplus
}
#endif
#endif	/* AESE_H */

