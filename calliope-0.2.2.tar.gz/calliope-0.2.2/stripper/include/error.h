/* 
 * File:   error.h
 * Author: desmond
 *
 * Created on 12 April 2011, 6:20 AM
 */

#ifndef ERROR_H
#define	ERROR_H

void error( const char *fmt, ... );
void warning( const char *fmt, ... );


#endif	/* ERROR_H */

